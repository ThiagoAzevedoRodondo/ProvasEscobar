import React from 'react'

import { View, Text } from 'react-native'

import Rotas from './routes'

const App = () => {
  return (
      <Rotas />
  )
}

export default App