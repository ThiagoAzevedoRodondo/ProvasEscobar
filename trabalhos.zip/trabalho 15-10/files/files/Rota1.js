import React from 'react'
import { View, Button, Text } from 'react-native'

const Rota1 = () => {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center"}}>
      <Text>Rota 1</Text>
    </View>
  )
}

export default Rota1