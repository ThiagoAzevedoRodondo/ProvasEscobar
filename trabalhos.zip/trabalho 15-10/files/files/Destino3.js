import React from 'react'
import { View, Button, Text } from 'react-native'

const Destino3 = () => {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center"}}>
      <Text>Destino 3</Text>
    </View>
  )
}

export default Destino3