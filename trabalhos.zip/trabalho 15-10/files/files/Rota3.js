import React from 'react'
import { View, Button, Text } from 'react-native'

const Rota3 = () => {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center"}}>
      <Text>Rota 3</Text>
    </View>
  )
}

export default Rota3
